int a[4];

int main()
{
	a[1] = 2;
	return 0;
}
