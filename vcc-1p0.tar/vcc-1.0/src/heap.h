#ifndef __HEAPS__
#define __HEAPS__

void addInitElement(char *constant, const int idx);

#endif
