#ifndef __BOOLEAN__
#define __BOOLEAN__


typedef enum
{
	false = 0,
	true
} bool;

#endif
